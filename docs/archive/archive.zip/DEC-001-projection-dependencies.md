---
id: DEC-001
title: A projection may depend on the artifact implementer
summary: The vocabulary and its reference codec stay dependency-free, while a projection module may import the implementer it targets — pyfmi_interop for the FMI adapter, the SysML parser for the port library.
date: 2026-11-19
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - docs/breakdown/00-intent/intent.md
  - AGENTS.md
  - pyproject.toml
supersedes: []
superseded_by: []
related: []
---

# DEC-001: A projection may depend on the artifact implementer

## Context

The repository promised no dependency on another `pysos_*` or `pyssp_*`
package at `0.1.0`, and that consumers depend on it, never the reverse.
That protected a real property: the vocabulary and its reference codec
import nothing, so a consumer takes them without an artifact toolchain.

The next projection breaks the letter of it: the RPR shape must reach a
simulation as an FMI 2.0 adapter carrying `rpr.v2` payloads, so a
projection must run `pyfmi_interop`'s generator, codegen and packager.
The alternatives were a third repository, or a second generator here.

## Decision

Dependency edges follow the projection, not the repository. The schema,
its bindings and its reference codec import no sibling package; a test
enforces it. A projection module may import the implementer it projects
onto (`pyfmi_interop`, `pyfmi_sysml2`) as a pinned extra. No implementer
imports a projection module, so the graph stays vocabulary ← projection
→ implementer.

## Rationale

A projection is defined by the artifact it produces. Refusing the dependency
does not remove the coupling; it relocates it into a duplicate generator or an
empty repository, both harder to audit than one pinned `pyproject.toml` edge. A
structured dependency also states the direction: `pysos_rpr` does not sit below
`pyfmi_interop` in any global sense, it sits beside it and points at it from one
optional module.

## Alternatives Considered

- **A third repository (`pysos_rpr_fmu`).** Honest, but it would exist only to
  hold a single projection with a single implementer, and still needs the same
  code.
- **Hosting the projection in `pyfmi_rpr`.** It pins both siblings, but it is
  the wire-boundary translator; it neither owns the vocabulary nor emits
  artifacts.
- **Putting RPR inside `pyfmi_interop`.** Rejected by that repository's intent:
  it does not translate between protocols, and RPR vocabularies are named as a
  separate repository's job.

## Consequences

- `pysos_rpr` gains optional extras; installing the vocabulary alone stays
  import-clean and cheap.
- "No runtime of its own" is restated, not dropped: the artifact is produced by
  the implementer, never by this package.
- The `0.1.0` dependency-free promise is narrowed to the vocabulary and codec.
  Consumers on that promise keep it; nothing they import gains a dependency.
- An import test must guard both directions, or purity decays the first time
  someone adds a convenient import.

## Verification

Not yet verified: no projection module exists, so this record lands as policy
ahead of code. It is verified when the first projection module (a) resolves the
pinned `pyfmi_interop` extra, (b) builds its artifact in that repository's
suite, and (c) an import test proves `import pysos_rpr` and
`import pysos_rpr.messages` pull no sibling package while no sibling package
imports a projection module.

## Review Trigger

Revisit if a projection starts needing a second implementer, if an import cycle
appears between this package and `pyfmi_interop` or `pyfmi_sysml2`, or if the
vocabulary-only install stops being dependency-free.
